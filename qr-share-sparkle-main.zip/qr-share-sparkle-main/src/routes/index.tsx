import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useRef, useState } from "react";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Drop & Share — Upload files and share via QR code" },
      { name: "description", content: "Upload files or entire folders and instantly generate a QR code to share them with anyone." },
      { property: "og:title", content: "Drop & Share" },
      { property: "og:description", content: "Upload files or folders and share them via QR code." },
    ],
  }),
  component: Index,
});

type FileMeta = { name: string; size: number; type: string };
type HistoryEntry = {
  id: string;
  files: FileMeta[];
  count: number;
  size: number;
  date: string;
};
type LogEntry = { id: string; ts: string; level: "info" | "ok" | "warn"; msg: string };

const STORAGE_KEY = "drop-share-history";

const formatSize = (b: number) => {
  if (b < 1024) return `${b} B`;
  if (b < 1024 * 1024) return `${(b / 1024).toFixed(1)} KB`;
  if (b < 1024 * 1024 * 1024) return `${(b / 1024 / 1024).toFixed(1)} MB`;
  return `${(b / 1024 / 1024 / 1024).toFixed(2)} GB`;
};

const formatDate = (iso: string) =>
  new Date(iso).toLocaleString(undefined, {
    day: "2-digit",
    month: "short",
    hour: "2-digit",
    minute: "2-digit",
  });

const fileIcon = (type: string, name: string) => {
  if (type.startsWith("image/")) return "fa-file-image";
  if (type.startsWith("video/")) return "fa-file-video";
  if (type.startsWith("audio/")) return "fa-file-audio";
  if (type.includes("pdf")) return "fa-file-pdf";
  if (type.includes("zip") || /\.(zip|rar|7z|tar|gz)$/i.test(name)) return "fa-file-zipper";
  if (type.includes("text") || /\.(md|txt|log)$/i.test(name)) return "fa-file-lines";
  if (/\.(js|ts|tsx|jsx|py|go|rs|java|cpp|c|html|css)$/i.test(name)) return "fa-file-code";
  return "fa-file";
};

function Index() {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const folderInputRef = useRef<HTMLInputElement>(null);
  const [files, setFiles] = useState<File[]>([]);
  const [previews, setPreviews] = useState<Record<string, string>>({});
  const [dragging, setDragging] = useState(false);
  const [done, setDone] = useState(false);
  const [history, setHistory] = useState<HistoryEntry[]>([]);
  const [logs, setLogs] = useState<LogEntry[]>([]);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) setHistory(JSON.parse(raw));
    } catch {
      /* ignore */
    }
    pushLog("info", "Session started — ready to upload");
  }, []);

  // Image previews via ObjectURL
  useEffect(() => {
    const map: Record<string, string> = {};
    files.forEach((f, i) => {
      if (f.type.startsWith("image/")) {
        map[`${i}-${f.name}`] = URL.createObjectURL(f);
      }
    });
    setPreviews(map);
    return () => Object.values(map).forEach((u) => URL.revokeObjectURL(u));
  }, [files]);

  const persist = (next: HistoryEntry[]) => {
    setHistory(next);
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(next));
    } catch {
      /* ignore */
    }
  };

  const pushLog = (level: LogEntry["level"], msg: string) => {
    setLogs((prev) =>
      [{ id: crypto.randomUUID(), ts: new Date().toISOString(), level, msg }, ...prev].slice(0, 30),
    );
  };

  const shareUrl = useMemo(
    () => `https://drop-share.app/s/${Math.random().toString(36).slice(2, 10)}`,
    [done],
  );
  const qrSrc = `https://api.qrserver.com/v1/create-qr-code/?size=260x260&margin=0&bgcolor=33-30-46&color=FFFFFF&data=${encodeURIComponent(shareUrl)}`;

  const handleFiles = (list: FileList | null) => {
    if (!list || list.length === 0) return;
    const arr = Array.from(list);
    setFiles(arr);
    setDone(true);
    const size = arr.reduce((s, f) => s + f.size, 0);
    const entry: HistoryEntry = {
      id: crypto.randomUUID(),
      files: arr.slice(0, 12).map((f) => ({
        name: (f as File & { webkitRelativePath?: string }).webkitRelativePath || f.name,
        size: f.size,
        type: f.type,
      })),
      count: arr.length,
      size,
      date: new Date().toISOString(),
    };
    persist([entry, ...history].slice(0, 50));
    pushLog("ok", `Uploaded ${arr.length} file${arr.length > 1 ? "s" : ""} · ${formatSize(size)}`);
    pushLog("info", `QR code generated for ${shareUrl}`);
  };

  const reset = () => {
    setFiles([]);
    setDone(false);
    if (fileInputRef.current) fileInputRef.current.value = "";
    if (folderInputRef.current) folderInputRef.current.value = "";
    pushLog("info", "Cleared current selection");
  };

  const clearHistory = () => {
    persist([]);
    pushLog("warn", "History cleared");
  };

  const copyLink = () => {
    navigator.clipboard?.writeText(shareUrl);
    setCopied(true);
    pushLog("ok", "Share link copied to clipboard");
    setTimeout(() => setCopied(false), 1600);
  };

  const totalSize = files.reduce((s, f) => s + f.size, 0);
  const stats = useMemo(() => {
    const totalFiles = history.reduce((s, h) => s + h.count, 0);
    const totalBytes = history.reduce((s, h) => s + h.size, 0);
    return { uploads: history.length, totalFiles, totalBytes };
  }, [history]);

  return (
    <div className="min-h-screen bg-background text-foreground relative overflow-hidden bg-noise">
      {/* Backdrop grid + blobs */}
      <div aria-hidden className="pointer-events-none absolute inset-0 -z-10 bg-grid">
        <div className="absolute inset-0" style={{ background: "var(--gradient-radial)" }} />
        <div className="absolute -top-40 -left-20 h-[28rem] w-[28rem] rounded-full bg-brand/25 blur-3xl animate-float-slow" />
        <div className="absolute top-1/2 -right-32 h-[26rem] w-[26rem] rounded-full bg-brand/20 blur-3xl animate-float-slower" />
        {/* Decorative shapes */}
        <svg className="absolute top-24 right-10 h-24 w-24 text-brand/30 animate-float-slower" viewBox="0 0 100 100" fill="none">
          <polygon points="50,5 95,80 5,80" stroke="currentColor" strokeWidth="1.5" />
        </svg>
        <svg className="absolute bottom-40 left-8 h-20 w-20 text-brand/25 animate-float-slow" viewBox="0 0 100 100" fill="none">
          <circle cx="50" cy="50" r="46" stroke="currentColor" strokeWidth="1.5" strokeDasharray="4 6" />
        </svg>
        <svg className="absolute top-1/3 left-1/4 h-12 w-12 text-brand/30" viewBox="0 0 100 100" fill="none">
          <rect x="10" y="10" width="80" height="80" stroke="currentColor" strokeWidth="1.5" transform="rotate(15 50 50)" />
        </svg>
      </div>

      {/* Header */}
      <header className="sticky top-0 z-20 backdrop-blur-md bg-background/60 border-b border-border">
        <div className="max-w-6xl mx-auto px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <span
              className="inline-flex h-9 w-9 items-center justify-center rounded-lg text-primary-foreground"
              style={{ backgroundImage: "var(--gradient-brand)", boxShadow: "var(--shadow-glow)" }}
            >
              <i className="fa-solid fa-paper-plane text-sm" />
            </span>
            <span className="font-semibold tracking-tight">Drop&nbsp;&amp;&nbsp;Share</span>
          </div>
          <nav className="hidden sm:flex items-center gap-6 text-sm text-muted-foreground">
            <a href="#upload" className="hover:text-foreground transition-colors">Upload</a>
            <a href="#activity" className="hover:text-foreground transition-colors">Activity</a>
            <a href="#history" className="hover:text-foreground transition-colors">History</a>
            <a href="#" className="inline-flex items-center gap-1.5 hover:text-foreground transition-colors">
              <i className="fa-brands fa-github" /> GitHub
            </a>
          </nav>
        </div>
      </header>

      <main className="max-w-6xl mx-auto px-6 pt-16 pb-24">
        {/* Hero */}
        <section className="text-center max-w-3xl mx-auto">
          <div className="inline-flex items-center gap-2 rounded-full border border-border bg-card/60 px-3 py-1 text-xs text-muted-foreground backdrop-blur">
            <span className="relative flex h-2 w-2">
              <span className="absolute inline-flex h-full w-full rounded-full bg-brand animate-pulse-ring" />
              <span className="relative inline-flex rounded-full h-2 w-2 bg-brand" />
            </span>
            End-to-end transfers · No account required
          </div>
          <h1 className="mt-6 text-5xl sm:text-6xl font-semibold tracking-tight leading-[1.05]">
            Share anything,{" "}
            <span
              className="bg-clip-text text-transparent"
              style={{ backgroundImage: "var(--gradient-brand)" }}
            >
              in one scan.
            </span>
          </h1>
          <p className="mt-5 text-muted-foreground text-lg max-w-xl mx-auto">
            Drop files or entire folders. We generate a QR code and a link your recipients can use on any device.
          </p>

          {/* Stat counters */}
          <div className="mt-8 grid grid-cols-3 gap-3 max-w-xl mx-auto">
            {[
              { label: "Uploads", value: stats.uploads, icon: "fa-bolt" },
              { label: "Files", value: stats.totalFiles, icon: "fa-file" },
              { label: "Transferred", value: formatSize(stats.totalBytes), icon: "fa-database" },
            ].map((s, i) => (
              <div key={i} className="relative rounded-xl border border-border bg-card/60 backdrop-blur p-4 overflow-hidden">
                <div className="absolute inset-x-0 -top-px h-px animate-shimmer" />
                <div className="flex items-center gap-2 text-xs text-muted-foreground">
                  <i className={`fa-solid ${s.icon} text-brand`} /> {s.label}
                </div>
                <div className="mt-1 text-2xl font-semibold tracking-tight tabular-nums">{s.value}</div>
              </div>
            ))}
          </div>
        </section>

        {/* Upload + side panel */}
        <section id="upload" className="mt-14 grid grid-cols-1 lg:grid-cols-5 gap-6">
          {/* Drop zone / result */}
          <div className="lg:col-span-3">
            {!done ? (
              <div
                onDragOver={(e) => {
                  e.preventDefault();
                  setDragging(true);
                }}
                onDragLeave={() => setDragging(false)}
                onDrop={(e) => {
                  e.preventDefault();
                  setDragging(false);
                  handleFiles(e.dataTransfer.files);
                }}
                className={`group relative rounded-2xl border border-dashed bg-card/50 backdrop-blur p-10 sm:p-14 text-center transition-all overflow-hidden ${
                  dragging ? "border-brand bg-card scale-[1.01]" : "border-border hover:border-brand/60"
                }`}
                style={{ boxShadow: dragging ? "var(--shadow-glow)" : undefined }}
              >
                <div
                  aria-hidden
                  className="absolute inset-0 opacity-60"
                  style={{ background: "var(--gradient-radial)" }}
                />
                <div className="relative">
                  <div className="relative inline-flex h-20 w-20 items-center justify-center mb-5">
                    <span className="absolute inset-0 rounded-full bg-brand/30 animate-pulse-ring" />
                    <span
                      className="relative inline-flex h-16 w-16 items-center justify-center rounded-full text-primary-foreground"
                      style={{ backgroundImage: "var(--gradient-brand)", boxShadow: "var(--shadow-glow)" }}
                    >
                      <i className="fa-solid fa-cloud-arrow-up text-2xl" />
                    </span>
                  </div>
                  <p className="font-medium text-xl">Drop files anywhere here</p>
                  <p className="mt-1.5 text-sm text-muted-foreground">
                    Multiple files & folders supported · Up to 2&nbsp;GB
                  </p>
                  <div className="mt-7 flex flex-wrap items-center justify-center gap-2">
                    <input
                      ref={fileInputRef}
                      type="file"
                      multiple
                      className="hidden"
                      onChange={(e) => handleFiles(e.target.files)}
                    />
                    <input
                      ref={folderInputRef}
                      type="file"
                      multiple
                      {...({ webkitdirectory: "", directory: "" } as Record<string, string>)}
                      className="hidden"
                      onChange={(e) => handleFiles(e.target.files)}
                    />
                    <button
                      onClick={() => fileInputRef.current?.click()}
                      className="inline-flex items-center gap-2 rounded-lg px-4 py-2.5 text-sm font-medium text-primary-foreground hover:opacity-90 transition-opacity"
                      style={{ backgroundImage: "var(--gradient-brand)", boxShadow: "var(--shadow-glow)" }}
                    >
                      <i className="fa-solid fa-file-arrow-up" /> Choose files
                    </button>
                    <button
                      onClick={() => folderInputRef.current?.click()}
                      className="inline-flex items-center gap-2 rounded-lg border border-border bg-secondary/60 px-4 py-2.5 text-sm font-medium hover:bg-secondary transition-colors"
                    >
                      <i className="fa-solid fa-folder-open" /> Choose folder
                    </button>
                  </div>
                  <div className="mt-6 flex items-center justify-center gap-4 text-xs text-muted-foreground">
                    <span className="inline-flex items-center gap-1.5"><i className="fa-solid fa-lock" /> Encrypted</span>
                    <span className="inline-flex items-center gap-1.5"><i className="fa-solid fa-bolt" /> Instant link</span>
                    <span className="inline-flex items-center gap-1.5"><i className="fa-solid fa-clock" /> 7-day expiry</span>
                  </div>
                </div>
              </div>
            ) : (
              <div className="relative rounded-2xl border border-border bg-card/70 backdrop-blur p-6 sm:p-7 overflow-hidden" style={{ boxShadow: "var(--shadow-elegant)" }}>
                <div aria-hidden className="absolute inset-0 opacity-50" style={{ background: "var(--gradient-radial)" }} />
                <div className="relative">
                  <div className="flex items-start justify-between gap-4">
                    <div>
                      <div className="inline-flex items-center gap-2 rounded-full bg-brand-soft text-brand px-2.5 py-1 text-xs font-medium">
                        <i className="fa-solid fa-circle-check" /> Ready to share
                      </div>
                      <p className="mt-3 text-2xl font-semibold tabular-nums">
                        {files.length} <span className="text-base font-normal text-muted-foreground">file{files.length > 1 ? "s" : ""} · {formatSize(totalSize)}</span>
                      </p>
                    </div>
                    <button
                      onClick={reset}
                      className="inline-flex items-center gap-1.5 rounded-lg border border-border bg-secondary/60 px-3 py-1.5 text-xs font-medium hover:bg-secondary transition-colors"
                    >
                      <i className="fa-solid fa-arrow-rotate-left" /> New
                    </button>
                  </div>

                  <div className="mt-5 grid grid-cols-1 sm:grid-cols-[auto_1fr] gap-6 items-start">
                    <div
                      className="rounded-xl p-1"
                      style={{ backgroundImage: "var(--gradient-brand)", boxShadow: "var(--shadow-glow)" }}
                    >
                      <div className="rounded-lg bg-card p-2.5">
                        <img src={qrSrc} alt="QR code to share files" className="h-40 w-40" />
                      </div>
                    </div>

                    <div className="min-w-0">
                      {/* Previews grid */}
                      <p className="text-xs uppercase tracking-wider text-muted-foreground mb-2">Preview</p>
                      <div className="grid grid-cols-4 sm:grid-cols-5 gap-2">
                        {files.slice(0, 10).map((f, i) => {
                          const key = `${i}-${f.name}`;
                          const url = previews[key];
                          return (
                            <div key={key} className="relative aspect-square rounded-md overflow-hidden border border-border bg-secondary/60 group">
                              {url ? (
                                <img src={url} alt={f.name} className="h-full w-full object-cover" />
                              ) : (
                                <div className="h-full w-full flex items-center justify-center text-muted-foreground">
                                  <i className={`fa-solid ${fileIcon(f.type, f.name)} text-lg`} />
                                </div>
                              )}
                              <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/70 to-transparent px-1 py-0.5">
                                <p className="text-[10px] truncate text-white/90">{f.name}</p>
                              </div>
                            </div>
                          );
                        })}
                        {files.length > 10 && (
                          <div className="aspect-square rounded-md border border-border bg-secondary/60 flex items-center justify-center text-xs text-muted-foreground">
                            +{files.length - 10}
                          </div>
                        )}
                      </div>

                      <div className="mt-4 flex items-center gap-2 rounded-lg border border-border bg-secondary/60 px-3 py-2">
                        <i className="fa-solid fa-link text-muted-foreground text-sm" />
                        <span className="truncate text-sm flex-1">{shareUrl}</span>
                        <button
                          onClick={copyLink}
                          className="text-xs font-medium text-brand hover:text-foreground transition-colors inline-flex items-center gap-1"
                        >
                          <i className={`fa-solid ${copied ? "fa-check" : "fa-copy"}`} /> {copied ? "Copied" : "Copy"}
                        </button>
                      </div>

                      <div className="mt-3 flex flex-wrap gap-2">
                        <a
                          href={qrSrc}
                          download="qr-code.png"
                          className="inline-flex items-center gap-2 rounded-lg px-3.5 py-2 text-sm font-medium text-primary-foreground hover:opacity-90 transition-opacity"
                          style={{ backgroundImage: "var(--gradient-brand)" }}
                        >
                          <i className="fa-solid fa-download" /> Download QR
                        </a>
                        <button
                          onClick={() => navigator.share?.({ url: shareUrl }).catch(() => {})}
                          className="inline-flex items-center gap-2 rounded-lg border border-border bg-secondary/60 px-3.5 py-2 text-sm font-medium hover:bg-secondary transition-colors"
                        >
                          <i className="fa-solid fa-share-nodes" /> Share
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Activity log */}
          <aside id="activity" className="lg:col-span-2">
            <div className="rounded-2xl border border-border bg-card/60 backdrop-blur overflow-hidden h-full flex flex-col">
              <div className="flex items-center justify-between px-4 py-3 border-b border-border">
                <div className="flex items-center gap-2 text-sm font-medium">
                  <span className="relative flex h-2 w-2">
                    <span className="absolute inline-flex h-full w-full rounded-full bg-brand opacity-75 animate-ping" />
                    <span className="relative inline-flex rounded-full h-2 w-2 bg-brand" />
                  </span>
                  Live activity
                </div>
                <span className="text-xs text-muted-foreground tabular-nums">{logs.length} events</span>
              </div>
              <ul className="flex-1 max-h-[420px] overflow-y-auto font-mono text-xs divide-y divide-border">
                {logs.length === 0 && (
                  <li className="px-4 py-6 text-center text-muted-foreground">No events yet…</li>
                )}
                {logs.map((l) => (
                  <li key={l.id} className="px-4 py-2 flex items-start gap-2.5">
                    <span className="text-muted-foreground tabular-nums shrink-0">
                      {new Date(l.ts).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", second: "2-digit" })}
                    </span>
                    <span
                      className={`shrink-0 uppercase text-[10px] font-semibold px-1.5 py-0.5 rounded ${
                        l.level === "ok"
                          ? "bg-brand-soft text-brand"
                          : l.level === "warn"
                          ? "bg-destructive/15 text-destructive"
                          : "bg-secondary text-muted-foreground"
                      }`}
                    >
                      {l.level}
                    </span>
                    <span className="text-foreground/90 break-all">{l.msg}</span>
                  </li>
                ))}
              </ul>
            </div>
          </aside>
        </section>

        {/* How it works */}
        <section className="mt-20">
          <div className="text-center mb-8">
            <p className="text-xs uppercase tracking-[0.2em] text-brand">Workflow</p>
            <h2 className="mt-2 text-3xl font-semibold tracking-tight">Three steps. Zero friction.</h2>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            {[
              { icon: "fa-upload", title: "Upload", text: "Drop one file, many files, or a whole folder.", n: "01" },
              { icon: "fa-qrcode", title: "Generate", text: "We create a QR code and a short link instantly.", n: "02" },
              { icon: "fa-share-nodes", title: "Share", text: "Anyone with the QR or link can download.", n: "03" },
            ].map((s, i) => (
              <div key={i} className="relative rounded-2xl border border-border bg-card/60 backdrop-blur p-6 overflow-hidden">
                <span className="absolute top-3 right-4 text-5xl font-bold text-brand/15 tabular-nums">{s.n}</span>
                <div
                  className="inline-flex h-11 w-11 items-center justify-center rounded-xl text-primary-foreground mb-4"
                  style={{ backgroundImage: "var(--gradient-brand)", boxShadow: "var(--shadow-glow)" }}
                >
                  <i className={`fa-solid ${s.icon}`} />
                </div>
                <p className="font-semibold text-lg">{s.title}</p>
                <p className="mt-1 text-sm text-muted-foreground">{s.text}</p>
              </div>
            ))}
          </div>
        </section>

        {/* History */}
        <section id="history" className="mt-20">
          <div className="flex items-center justify-between mb-5">
            <div>
              <p className="text-xs uppercase tracking-[0.2em] text-brand">Memory</p>
              <h2 className="mt-1 text-2xl font-semibold tracking-tight flex items-center gap-2">
                <i className="fa-solid fa-clock-rotate-left" /> Recent uploads
              </h2>
            </div>
            {history.length > 0 && (
              <button
                onClick={clearHistory}
                className="text-xs text-muted-foreground hover:text-destructive transition-colors inline-flex items-center gap-1.5"
              >
                <i className="fa-solid fa-trash" /> Clear history
              </button>
            )}
          </div>

          {history.length === 0 ? (
            <div className="rounded-2xl border border-dashed border-border bg-card/40 p-10 text-center text-sm text-muted-foreground">
              <i className="fa-regular fa-folder-open text-3xl mb-3 block text-brand/60" />
              No uploads yet — your history will appear here.
            </div>
          ) : (
            <ul className="rounded-2xl border border-border bg-card/60 backdrop-blur divide-y divide-border overflow-hidden">
              {history.map((h) => (
                <li key={h.id} className="flex items-center gap-3 p-4 hover:bg-secondary/40 transition-colors">
                  <span
                    className="inline-flex h-10 w-10 shrink-0 items-center justify-center rounded-lg text-primary-foreground"
                    style={{ backgroundImage: "var(--gradient-brand)" }}
                  >
                    <i className="fa-solid fa-file-zipper text-sm" />
                  </span>
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm font-medium">
                      {h.files.slice(0, 2).map((f) => f.name).join(", ")}
                      {h.count > 2 ? ` + ${h.count - 2} more` : ""}
                    </p>
                    <p className="text-xs text-muted-foreground tabular-nums">
                      {h.count} file{h.count > 1 ? "s" : ""} · {formatSize(h.size)} · {formatDate(h.date)}
                    </p>
                  </div>
                  <i className="fa-solid fa-chevron-right text-xs text-muted-foreground" />
                </li>
              ))}
            </ul>
          )}
        </section>
      </main>

      <footer className="border-t border-border">
        <div className="max-w-6xl mx-auto px-6 py-6 flex items-center justify-between text-xs text-muted-foreground">
          <span className="inline-flex items-center gap-1.5">
            <i className="fa-solid fa-paper-plane text-brand" /> Drop & Share
          </span>
          <span>Built with <i className="fa-solid fa-heart text-brand mx-0.5" /> · 2026</span>
        </div>
      </footer>
    </div>
  );
}
